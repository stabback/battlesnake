declare module 'fast-cartesian';
