# Josh's Battlesnakes

This repo contains my experiments with battlesnakes.  They are written in Node with Typescript.

## Development

```sh
npm i
npm run dev
```

This compiles and serves your snakes locally.

## Pushing to gcloud

```sh
gcloud deploy
```
