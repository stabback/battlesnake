import pressure from './pressure'
import eat from './eat'

export default {
    pressure,
    eat
}
