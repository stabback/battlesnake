import attack from './attack'
import eat from './eat'
import random from './random'

export default {
    attack,
    eat,
    random
}
